<?php

$servername ="50.116.92.151";// "localhost";
$username = "j0qvbg2o_admin";
$password = "Intheend11!";
$dbName = "j0qvbg2o_EASY_BIZI";

$link = mysqli_connect($servername, $username, $password, $dbName);
mysqli_set_charset($link, "utf8");
